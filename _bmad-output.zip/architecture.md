# PC-Assistant Architecture (Brownfield Hardening)
Date: 2025-12-18
Track: BMad Method, brownfield
Scope: Harden plan → execute → verify loops for Windows desktop automation with strong safety and
grounding. Target users: developers/researchers/power users on Windows 10/11 (local, standard
permissions; explicit consent for privileged/destructive actions).

## Context & Goals
- Improve reliability of multimodal automation: predictable planning, validated execution, evidence.
- Strengthen perception: OCR+bboxes, UIA/locators, optional VLM reading; choose per task.
- Enforce guardrails: target/window verification, consent prompts, bounded retries, clear failures.
- Keep provider-agnostic LLM/VLM interfaces (DeepSeek/Doubao/Qwen) and browser automation stack.
- Preserve brownfield assets; refactor incrementally toward maintainable modules.

## High-Level Architecture
- Electron UI (renderer) → backend HTTP API (FastAPI) → planning/execution pipeline →
  perception stack (screenshot/OCR/UIA/VLM) → action drivers (Win32/UIA, browser, file ops).
- Logging/observability: request IDs, structured logs, screenshots, OCR/VLM outputs, verification
  artifacts. Evidence surfaced in UI.
- Config/caches: .env for keys; backend/data for app alias/path caches; logs/ for Electron and
  backend traces.

## Component Responsibilities
- Frontend (Electron)
  - Main: spawn/monitor backend, log rotation, health checks.
  - Renderer: modes (dry-run, step-by-step, safe auto-run), provider/mode selection, workdir, shows
    plan/evidence/logs; offers retry/adjust/abort on failures.
  - Preload: IPC bridge (logging, backend URL, file selection).
- Backend API (FastAPI)
  - Ingress: accept user_text + optional screenshot/OCR/manual click; issue request IDs; run through
    planning/execution/verification; return results and artifacts.
  - Routing: provider availability checks; safety gating hooks.
- Planning & Policy
  - planner_prompt + action_parser produce ActionPlan → pydantic validation via actions_schema.
  - Heuristics (e.g., enforce open_app for launch intents, dedupe redundant clicks, normalize steps).
  - Mode policy: dry-run (no side effects), step-by-step (user confirms), safe auto-run (auto but
    pauses on risky actions per safety_policy.yaml).
  - Provider selection: pick configured LLM/VLM (DeepSeek/Doubao/Qwen) based on capability and
    vision needs; fall back if unavailable.
- Perception
  - Screenshot capture (mss) with metadata.
  - OCR with bounding boxes (pytesseract); extracted text fed to planner and verification.
  - UIA/locators (vision/uia_locator, executor/ui_locator) for target discovery when available.
  - Optional VLM reading (llm/vlm_client pattern) for complex UI/text; store outputs with confidence
    when invoked.
  - Strategy selection: choose cheapest sufficient method (UIA/locator > OCR > VLM) unless policy
    forces higher-fidelity; record chosen path.
- Execution Engine
  - TaskContext + TaskRegistry track status, retries, outcomes; supports action set (mouse/keyboard,
    browser_click/input/extract, file ops, wait, window focus, scroll/drag).
  - Pre-checks: active window verification; block background input; ensure coordinates/targets from
    latest perception pass; confirm app launch/open_app when needed.
  - Safety: consent for destructive ops (delete/move sensitive files, system settings), forbid silent
    privilege escalation; configurable via safety_policy.yaml and request flags.
  - Post-checks: verify expected UI/text/state; rerun perception (OCR/locator) for validation; retry
    with bounded attempts and jitter; fail with evidence if still broken.
- Browser Automation
  - Use existing browser_* actions and locator strategies; ensure navigation/fill/submit steps log
    DOM/text evidence; verify success criteria after submission.
- File Operations
  - Guarded actions with dry-run preview; confirmation for deletes/moves; post-verification (exists /
    removed / checksum if needed).
- Observability & Evidence
  - Structured logging (backend/logging_setup, logging_utils) with request IDs; summarize plans and
    executions; capture screenshots, OCR text, locator/VLM outputs, verification results, retries.
  - Surface evidence to UI for inspectable runs; retain on disk with user-controlled retention.
- Error Handling & Recovery
  - Every failure returns: error code/message, evidence (screenshot/text), suggested next action
    (retry/adjust/abort/manual takeover).
  - Support manual takeover for CAPTCHAs/logins/unknown dialogs; resume automation afterward.

## Data & Configuration
- Environment: .env for provider keys (DeepSeek/Doubao/Qwen), host/port overrides; defaults in
  backend/config.py.
- Caches: backend/data/app_alias_cache.json, app_path_cache.json; guard writes with locks.
- Safety policy: backend/config/safety_policy.yaml to enumerate risky actions and consent rules.
- Artifacts: logs/ (Electron + backend), _bmad-output/ (tracking docs), future run/evidence folders
  per request ID.

## Non-Functional Requirements (reinforced)
- Reliability: deterministic validation of plans; bounded retries; explainable failures with
  artifacts.
- Latency: planning within a few seconds; UI actions responsive; avoid unnecessary full-screen scans
  unless required.
- Privacy: local-first; no silent exfiltration; user controls log/screenshot retention.
- Resource: efficient on CPU; optional GPU; avoid heavy VLM unless needed.

## Demo Readiness (acceptance alignment)
1) Browser flow: multi-step form with verification, dynamic text extraction, evidence logged.
2) Desktop UI flow: OCR/locator-driven actions with window focus checks, safety gates, retries.
3) File ops flow: create/move/delete with consent prompts and post-verification; clear logs/evidence.

## Extensibility & Next Steps
- Abstract provider interface further for new LLM/VLMs; add confidence scores and fallbacks.
- Add action middleware for pre/post hooks (safety, logging, retries) to reduce per-action drift.
- Standardize evidence package per step (screenshot ref, locator strategy, observed text, outcome).
- Add safety classification layer to score planned actions and require confirmation when high risk.
- Broaden test harness: scenario tests for browser, UI automation, and file ops with mocked inputs.

## Open Decisions / Risks
- Evidence retention policy (duration, scrubbing of sensitive text/screenshots).
- Handling of credential/PII fields (masking, confirmation prompts).
- GPU/accelerator usage policy for VLM; fallback quality on CPU-only.
- Packaging for distribution (venv bundling, Electron packaging) and update strategy.
