# PC-Assistant Epics and Stories (Brownfield Hardening)
Date: 2025-12-18
Inputs: _bmad-output/prd.md, _bmad-output/architecture.md, _bmad-output/index.md
Scope: Hardening plan → execute → verify loops, safety/guardrails, perceptual grounding, and observability for Windows desktop automation (developers/researchers/power users).

## Epic E1: Reliable Plan–Execute–Verify Loop
- Story S1: Plan validation and dry-run
  - As a user, I can see the parsed intent and proposed action plan before any side effects, choose dry-run/step-by-step/safe auto-run, and plans are schema-validated (actions_schema) with obvious errors surfaced.
  - Acceptance: Plan is rendered in UI; invalid steps rejected with clear errors; choosing dry-run executes no side effects and returns the plan and evidence hooks.
- Story S2: Execution gating and focus safety
  - As a user, executions only run when the target window/focus is verified; background clicks/keystrokes are blocked.
  - Acceptance: For any UI action, active window is checked; if mismatch, user is prompted to confirm/switch; blocked actions are logged with reason.
- Story S3: Post-action verification with bounded retries
  - As a user, each action has a configured verification (UI/text/state) and bounded retries; failures include evidence.
  - Acceptance: Each action logs expected vs observed; retries capped; final failure returns screenshot + extracted text + locator info.

## Epic E2: Safety & Consent
- Story S4: Risk scoring and consent prompts
  - As a user, risky actions (delete/move sensitive files, installs, system settings, credential entry) require explicit confirmation; silent privilege escalation is blocked.
  - Acceptance: safety_policy.yaml drives prompts; attempts without consent are denied with clear messaging.
- Story S5: File operations with confirmations and post-checks
  - As a user, file create/move/delete operations preview changes, prompt for confirmation, and verify results.
  - Acceptance: Deletes/moves require confirmation; post-check validates existence/absence; logs include paths and outcomes.
- Story S6: Human-in-the-loop takeover
  - As a user, I can request manual takeover for CAPTCHAs/login/unknown dialogs and resume automation afterward.
  - Acceptance: “take_over” action is exposed; logs mark manual segments; resuming continues with updated context.

## Epic E3: Multimodal Perception & Grounding
- Story S7: Strategy selection across OCR/UIA/VLM
  - As a user, the system chooses the cheapest sufficient perception method (locator/UIA → OCR → VLM) per task and records the choice.
  - Acceptance: Each step logs chosen method and fallback path; VLM invoked only when cheaper methods fail/ambiguous.
- Story S8: Target evidence packaging
  - As a user, every UI interaction includes evidence (screenshot reference, bounding boxes/locators, extracted text) bundled with the action.
  - Acceptance: Evidence object returned per action; UI can render highlights; logs persist references.
- Story S9: Vision fallback policy
  - As a user, when OCR confidence is low or layout is dynamic, VLM-based reading can be used with a clear flag and timeout guard.
  - Acceptance: VLM calls respect time/resource caps; outputs tagged with confidence; fallbacks logged.

## Epic E4: Observability & UX
- Story S10: Evidence and logs in UI
  - As a user, I can view plan, actions, evidence (screenshots/boxes/text), and verification results in the Electron UI.
  - Acceptance: Renderer surfaces per-step evidence; request IDs are shown; failures are clickable to details.
- Story S11: Actionable failure diagnostics
  - As a user, failures provide a recommended next action (retry/adjust/abort) with rationale.
  - Acceptance: Each failure response includes recommended action and why (e.g., “target not found; try refresh or adjust locator”).
- Story S12: Run metadata and retention
  - As a user, runs are tagged with request IDs and retention policy; I can configure log/screenshot retention.
  - Acceptance: Configurable retention setting; logs note when evidence is pruned; request ID is propagated end-to-end.

## Epic E5: Browser Automation Robustness
- Story S13: Multi-step form with verification
  - As a user, I can run a multi-step browser workflow (navigate, fill, submit) with verification of submitted values and success messages.
  - Acceptance: DOM/text evidence captured for each step; mismatches trigger retries or clear failure with evidence.
- Story S14: Adaptive text extraction
  - As a user, browser extraction chooses between DOM, OCR, and VLM when DOM is insufficient.
  - Acceptance: Method choice logged; verification uses extracted values; fallbacks constrained by safety/timeouts.

## Epic E6: File Operation Guardrails (Demo Alignment)
- Story S15: Guarded file workflow
  - As a user, I can perform create/read/move/delete with confirmations and post-verification.
  - Acceptance: Confirmation prompt precedes destructive ops; post-check ensures state; logs/evidence recorded.

## Dependencies & Notes
- Reuse existing executor, vision (OCR/UIA), LLM clients, safety_policy.yaml, Electron UI.
- Provider-agnostic LLM/VLM; optional GPU; default CPU.
- Evidence/logging relies on request IDs from backend/logging_utils; ensure UI can fetch/render evidence blobs.

## Test Coverage Targets
- Happy-path scenarios for S13, S2/S3, S5/S15.
- Failure paths: blocked background action, missing target, consent denied, low-confidence OCR with VLM fallback.
- Evidence serialization round-trip to UI (rendered highlights/summaries).
