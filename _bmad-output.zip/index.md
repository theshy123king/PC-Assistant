# PC-Assistant Project Documentation (deep scan)
Generated: 2025-12-18T10:42:37
Scan level: deep (initial_scan)
Project type: multi-part (backend=backend, frontend=desktop)

## Overview
- Brownfield Windows desktop agent for multimodal assistance (vision+LLM) and automated execution.
- Production-minded goal: stable, extensible assistant with planning, execution, and UI automation.

## Repository Structure
- backend/ ? FastAPI service; execution engine, LLM clients, vision pipeline, Windows automation helpers.
- frontend/ ? Electron shell; main process spawns/monitors backend; renderer UI for chat/execute flows.
- scripts/, logs/, _bmad/, _bmad-output/ (tracking), assets/data caches under backend/data/.

## Backend (Python, FastAPI)
- Entrypoint: backend/app.py (FastAPI); routes wire user text + optional OCR/screenshot to planner/executor; uses logging utilities and provider availability checks.
- Launch helper: backend/launch_backend.py ensures dev/test host/port hygiene before starting uvicorn (process cleanup if port busy).
- Config: backend/config.py resolves dev/test host/port; safety policy at backend/config/safety_policy.yaml.
- Execution: backend/executor/ ? action schemas (click, browser_* interactions, file ops, wait, etc.), task registry/context, UI automation (apps.py with alias/path caches, ui_locator/uia_rebind, files/mouse helpers), main executor loop.
- Vision: backend/vision/ ? screenshot capture, OCR, UI/icon/VLM locators.
- LLM: backend/llm/ ? planner prompt bundle and provider clients (deepseek, doubao, qwen); test_planner harness.
- Utilities: backend/utils/ ? time helpers, win32 foreground focus management.
- Data: backend/data/app_alias_cache.json and app_path_cache.json seed/cached app lookups.
- Tests: backend/tests/ covering executor, vision, llm; fixtures in test_data/mock_pages/screenshots.
- Dependencies (backend/requirements.txt): fastapi, uvicorn, mss, pillow, pytesseract, python-dotenv, httpx, dashscope, pyautogui, pygetwindow, uiautomation, PyYAML, psutil.

## Frontend (Electron)
- Main: frontend/main.js ? creates BrowserWindow, spawns/monitors backend (uses venv/Scripts/python.exe when available), health checks http://<host>:<port>/, rotates logs in logs/electron-*.log.
- Preload: frontend/preload.js ? bridge for renderer logging and backend access (not inspected in detail during scan).
- Renderer: frontend/renderer/index.js ? chat/execute UI; provider selection (DeepSeek/Doubao/Qwen), mode toggle (execute/chat), workdir input, screenshot/OCR controls; calls backend at API_BASE (defaults 127.0.0.1:5004).
- Assets: frontend/renderer/index.html layout and styles.
- Scripts: package.json scripts (`npm start` -> electron ., `npm run backend` -> python -m backend.launch_backend).

## Run & Dev Notes
- Backend: python -m backend.launch_backend (ensures port cleanup) or uvicorn backend.app:app; env via .env (API keys for providers, host/port overrides).
- Frontend: from frontend/, npm install (already vendored) then npm start to launch Electron shell and backend.
- Tests: python -m pytest (per AGENTS.md; tests under backend/tests).
- Logs: stored under logs/ (electron-main/renderer); backend logging configured via backend/logging_setup.py.

## Current Outputs
- Workflow status: _bmad-output/bmm-workflow-status.yaml
- Documentation file: _bmad-output/index.md (this file)
