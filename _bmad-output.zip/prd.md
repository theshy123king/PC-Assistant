# PC-Assistant PRD (Brownfield Hardening)
Generated: 2025-12-18
Scope: Improve end-to-end reliability and safety of multimodal Windows desktop automation; harden plan → execute → verify loops with stronger visual grounding and execution guardrails.

## Goals
- Deliver predictable, inspectable automation for Windows 10/11 (64-bit) targeting developers/researchers/power users.
- Strengthen perception and grounding: flexible mix of OCR with bounding boxes, UIA/locators, and VLM-based reading where needed.
- Enforce safe execution: confirmations for risky steps, window/target verification before input, clear failure reporting with evidence and recovery options.
- Keep provider-agnostic LLM/VLM integration; default policies chosen per task type.

## Users & Environment
- Personas: developers, researchers, power users running locally; standard user permissions by default.
- Platform: Windows 10/11 desktop; CPU-first with optional GPU; offline automation should function without model calls when possible.

## Top Use Cases (this iteration)
1) Multi-step browser workflows with verification (navigate, fill forms, click, extract text, validate results).
2) Desktop UI automation using OCR+bounding boxes/UIA/locators (app-agnostic).
3) File operations with confirmations and post-checks (create/read/move/delete).
4) Dynamic text extraction strategy selection (OCR vs locator vs VLM) per content.
5) Inspectable runs: view plan, evidence, logs; fast debugging of failures.

## Functional Requirements
- Planning
  - Parse intent into structured action plans; select providers dynamically (DeepSeek/Doubao/Qwen) via pluggable interface.
  - Offer modes: dry-run (plan only), step-by-step, safe auto-run with confirmations for risky actions.
- Perception & Grounding
  - Capture screenshots; run OCR with bounding boxes; apply UIA/locator queries; optional VLM reading for hard cases.
  - Record which method was chosen and why; fall back across methods when confidence is low.
- Execution
  - Application control: mouse/keyboard actions, browser automation, file ops within user scope.
  - Guardrails: verify target window/focus before sending input; confirmations for destructive/sensitive actions; block silent privilege escalation.
  - Post-action verification: check expected UI/text/state; retry where safe with bounded attempts.
- Observability
  - Log plan, actions, inputs/outputs, screenshots, OCR/VLM text, verification results, errors; tag runs with request IDs.
  - Provide user-facing evidence in Electron UI (plan, targets/boxes, verification outcomes, retries).
- Human-in-the-loop
  - Allow takeover prompts for CAPTCHAs, logins, unknown dialogs; allow manual approval for sensitive steps.

## Non-Functional Requirements
- Reliability: failures must include clear error + evidence + suggested next action (retry/adjust/abort).
- Latency: planning completes within a few seconds; UI actions feel responsive; avoid long blocking operations.
- Safety: no background clicks/keys without target verification; enforce consent prompts for destructive/system-affecting actions.
- Privacy: local-first; no silent data exfiltration; user controls log/screenshot retention.
- Resource limits: efficient on CPU; GPU optional; avoid scanning entire file system by default.

## Integrations & Dependencies
- Reuse existing backend modules: executor, vision (screenshot/OCR/UIA locators), llm provider clients, utils.
- Electron frontend: main process spawns/monitors backend; renderer shows plans, modes, evidence, and results.
- Browser automation: continue existing stack; ensure alignment with verification/guardrail policy.
- Reference: borrow applicable patterns from Open-AutoGLM (tool framework, sensitive-action confirmations, multimodal grounding) adapted to Windows (Win32/UIA/locators).

## UX & Interaction
- Present parsed intent and proposed plan before execution; allow edits/confirmation.
- Modes: dry-run, step-by-step, safe auto-run with explicit confirmations for risky steps.
- Evidence panel: screenshots, bounding boxes/locators used, verification and retry outcomes; clear error surfaces.
- Failure handling: actionable diagnostics with retry/adjust/abort options.

## Constraints & Policies
- Allowed: UI automation, browser control, file ops within user scope.
- Forbidden: silent privilege escalation, destructive system changes without consent, silent credential entry.
- Consent prompts: deletes/moves of sensitive files, installs, system settings changes, credential input.
- Offline: automation should degrade gracefully; model-dependent features may be unavailable without connectivity.

## Acceptance Criteria (shippable demo)
1) Browser scenario: multi-step form/task with robust verification and dynamic text extraction; includes evidence/logging.
2) Desktop UI scenario: OCR/locator-driven automation with safety gates (window focus check, target confirmation) and retries.
3) File operation scenario: create/move/delete with confirmations and post-verification; produces clear logs/evidence.
Across all: every failure yields clear error + evidence + recommended next action; user can inspect plan/evidence in UI.

## Out of Scope (this iteration)
- Fully autonomous zero-oversight operation.
- macOS/Linux support.
- RL training, long-term memory systems, distributed/cloud execution.
