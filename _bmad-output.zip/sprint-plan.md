# PC-Assistant Sprint Plan (Hardening Sprint)
Date: 2025-12-18
Goal: Hardening plan → execute → verify loops, safety/guardrails, perception policy, and observability for Windows desktop automation.
Scope Basis: PRD, Architecture, Epics/Stories, Test Design, Implementation Readiness.

## Sprint Theme
Make automation reliable, inspectable, and safe: codify perception strategy, enforce safety/consent, add bounded retries/verification, and surface evidence to users.

## Prioritized Stories (from Epics)
1) S1 Plan validation & dry-run (actions_schema; mode selection; no side effects)
2) S2 Focus safety (block background clicks/keys; window verification)
3) S4 Risk scoring & consent prompts (safety_policy; path sensitivity)
4) S3 Post-action verification & bounded retries (with evidence)
5) S7/S8 Perception strategy selection + evidence bundling (UIA/locator → OCR → VLM)
6) S10 Evidence & logs surfaced in UI (request IDs; per-action evidence)
7) S15 File guardrails (confirmations + post-checks)
8) S13 Browser multi-step flow verification (form fill/submit with verification and fallbacks)
9) S11 Actionable failure diagnostics (retry/adjust/abort recommendations)

## Sprint Backlog Breakdown
- Backend – Planning/Policy
  - Validate/normalize plans against actions_schema; reject/repair invalid steps (S1).
  - Implement mode gating: dry-run (no input dispatch), step-by-step prompts, safe auto-run respecting safety_policy (S1/S4).
  - Enforce focus checks before UI actions; block background input with clear errors (S2).
  - Add safety classification + consent prompts for risky ops (delete/move sensitive files, installs/settings/credentials) using safety_policy.yaml and path rules (S4/S15).
- Backend – Execution/Verification
  - Add pre/post hooks for verification per action; bounded retries with jitter; return evidence on failure (S3/S9).
  - File ops: confirmations, scope checks, post-verification (exists/absent), dry-run preview (S15).
  - Browser flow helper: multi-step form with DOM-first, OCR fallback, VLM optional with timeout; verify submitted values/success indicator (S13/S14).
- Backend – Perception
  - Codify perception strategy: prefer UIA/locator, then OCR, then VLM; include confidence thresholds/timeouts; log chosen path (S7/S9).
  - Evidence package per action: screenshot ref, boxes/locators, extracted text, method used, verification result (S8/S10).
- Frontend (Electron)
  - Surface plan and per-action evidence (screenshots/boxes/text/method/verification, request_id) in renderer (S10).
  - Mode selectors (dry-run/step-by-step/safe auto-run) and consent prompts surfaced (S1/S4).
  - Failure view with recommended next action (retry/adjust/abort) (S11).
- Testing
  - Pytest scenarios: browser form success/fallback; desktop focus block/retry; file guardrails; consent prompts; perception fallback; dry-run no side effects; evidence serialization to UI (T1–T9).

## Milestones
- M1: Planning/policy enforced (plan validation, modes, safety gating, focus checks).
- M2: Verification/retry middleware and file guardrails implemented.
- M3: Perception strategy and evidence packages in backend.
- M4: UI surfaces evidence/modes/consent; failure diagnostics.
- M5: Tests added/green for core scenarios (browser, desktop, file, safety).

## Risks & Mitigations
- Latency from VLM: cap calls, use only when cheaper methods fail; timeouts.
- Missing consent coverage on new actions: central safety policy mapping + tests.
- Evidence retention/privacy: define retention/masking; allow user controls.
- CPU-only environments: ensure VLM optional with graceful degradation.

## Definition of Done
- Core stories S1–S8/S15 implemented with passing tests.
- Evidence available in UI for actions; request IDs propagated.
- Safety/consent and focus blocking enforced; retries bounded with verification.
- Browser and desktop demo scenarios pass with logged evidence; file guardrails verified.
