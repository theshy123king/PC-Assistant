# PC-Assistant Test Design (System-Level, Brownfield Hardening)
Date: 2025-12-18
Mode: system-level (Solutioning)
Scope: Validate testability for plan → execute → verify hardening across multimodal desktop automation (Windows 10/11). Inputs: PRD (_bmad-output/prd.md), Architecture (_bmad-output/architecture.md), Epics/Stories (_bmad-output/epics-and-stories.md), Docs (_bmad-output/index.md).

## Objectives
- Ensure safety/guardrail behaviors are testable and enforced (consent, window focus, background-blocking).
- Validate perception strategy selection (UIA/locator → OCR → VLM) and evidence packaging.
- Verify plan/execution/verification loop reliability with bounded retries and clear diagnostics.
- Cover browser, desktop UI, and file-operation scenarios with evidence/logging expectations.

## System-Level Test Design
### T1: Plan Validation & Safe Modes
- Goal: Plans are schema-valid; dry-run produces no side effects; mode selection enforced.
- Coverage:
  - Validate action plans against actions_schema; reject invalid/missing params.
  - Dry-run: returns plan/evidence hooks; no input events fired (assert no mouse/keyboard calls).
  - Step-by-step: pauses for confirmation before each risky action.
  - Safe auto-run: executes but prompts for consent on risky steps; uses safety_policy.yaml.
- Evidence: Logs include request_id, plan summary, validation result, chosen mode.
- Risks: Silent fallback to unsafe defaults; missing validation on new actions.

### T2: Focus & Background Safety
- Goal: Prevent background clicks/keys; ensure active window matches target.
- Coverage:
  - Attempt UI action when active window != target → action blocked with prompt; no input sent.
  - Confirmed focus switch then action proceeds.
  - Window loss mid-sequence triggers pause/prompt.
- Evidence: Logs show window info, block reason, user choice; screenshot on block.
- Risks: Race conditions between focus check and input dispatch.

### T3: Perception Strategy Selection
- Goal: Chooses cheapest sufficient method; logs choice and fallbacks.
- Coverage:
  - Simple target available via UIA/locator → uses locator, no OCR/VLM.
  - OCR low confidence triggers fallback to VLM with timeout; result tagged with confidence.
  - Ambiguous locator triggers OCR; conflicting results produce explicit warning.
- Evidence: Each step logs method, confidence, fallback chain; stores boxes/text.
- Risks: Overuse of VLM causing latency; missing confidence thresholds.

### T4: Post-Action Verification & Retries
- Goal: Actions verify expected state and retry with bounds.
- Coverage:
  - Success path: action → verify expected text/element → pass.
  - Failure then retry: first verify fails (target absent) → retry performs refresh/re-perception → success.
  - Bounded retries: after N attempts, fail with evidence and suggested next action.
- Evidence: Per-attempt logs (expected vs observed), screenshots, extracted text, retry count.
- Risks: Infinite retry loops; weak verification criteria.

### T5: Safety & Consent for Sensitive Ops
- Goal: Risky operations require explicit confirmation; blocked without consent.
- Coverage:
  - File delete/move in sensitive path prompts consent; decline blocks action.
  - System setting change/install attempt blocked or prompts; no action without approval.
  - Credential entry prompts handoff/manual mode.
- Evidence: Consent prompt recorded; decision logged; no side effects on decline.
- Risks: Paths misclassified; missing consent on new actions.

### T6: File Operation Guardrails
- Goal: Create/move/delete with confirmations and post-checks.
- Coverage:
  - Create file/folder → verify existence.
  - Move file → verify new path, absence at source.
  - Delete with confirmation → verify removal; protect outside allowed scope.
  - Dry-run shows proposed changes only.
- Evidence: File state before/after, confirmations, logs.
- Risks: Relative path resolution errors; unintended directories.

### T7: Browser Flow Robustness
- Goal: Multi-step form/task with verification and adaptive extraction.
- Coverage:
  - Navigate → fill → submit; verify submitted values and success indicator.
  - DOM extraction preferred; fallback to OCR; if DOM unavailable/blocked, VLM optional with timeout.
  - Handles dynamic text (e.g., toast) with re-perception.
- Evidence: DOM/text snapshots, screenshots with boxes, method used for extraction.
- Risks: Timing flakiness; overuse of VLM; brittle selectors.

### T8: Desktop UI Automation
- Goal: OCR/locator-driven interaction with safety gates and retries.
- Coverage:
  - Locate target via locator; fallback to OCR; execute click/input; verify text/state.
  - Window focus check before action; retry after UI changes.
  - Unknown dialogs trigger prompt/take_over path.
- Evidence: Screenshot, boxes/locators, verification result, retry log.
- Risks: Low OCR accuracy on themed UIs; blocking dialogs ignored.

### T9: Observability & Evidence Surfacing
- Goal: Evidence/logs are consistent and consumable by UI.
- Coverage:
  - Request ID propagation backend→UI.
  - Evidence package per action (screenshot ref, method, boxes/text, result) serialized and readable by renderer.
  - Retention policy respected; pruning is logged.
- Risks: Evidence lost or not surfaced; retention misconfig.

## Test Data & Fixtures
- Use mocked pages (backend/tests/mock_pages) for browser flows; screenshots/test_data for OCR cases.
- Provide synthetic UI screenshots with known text/boxes for OCR/VLM fallback tests.
- File ops in temporary workspace to avoid real user data.

## Tooling & Hooks
- Pytest for backend flows; ability to stub providers (LLM/VLM) and perception outputs.
- Hooks/mocks around executor input dispatch to assert no events in dry-run/blocked scenarios.
- Logging assertions on request_id, mode, safety decisions.

## Risks & Gaps
- VLM availability/latency on CPU-only; need graceful degradation paths.
- Confidence thresholds for OCR/VLM not yet standardized.
- Evidence retention policy not finalized; may affect UI display.
